<?php

require "db.php";

header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}

$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Email and password are required."
    ]);

    exit;
}

$sql = "SELECT id, full_name, email, password_hash, role, is_active
        FROM admin_users
        WHERE email = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Database query failed."
    ]);

    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();

if (!$user["is_active"]) {
    http_response_code(403);

    echo json_encode([
        "success" => false,
        "message" => "This account is inactive."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

if (!password_verify($password, $user["password_hash"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

echo json_encode([
    "success" => true,
    "id" => $user["id"],
    "role" => $user["role"],
    "fullName" => $user["full_name"],
    "email" => $user["email"]
]);

$stmt->close();
$conn->close();

?>